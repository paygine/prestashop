<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{paygine}prestashop>paygine_e3dcf5c3282b0e8dadd98682d911ac3e'] = 'Paygine';
$_MODULE['<{paygine}prestashop>paygine_93402b6ccc3ce0f507fa1c97059f3b2f'] = 'Принимайте платежи с банковских карт.'; // Accept payments for your products via credit and debit cards.
$_MODULE['<{paygine}prestashop>paygine_f9357d7517ee83a3d281702182c31823'] = 'Вы уверены, что хотите удалить этот модуль?'; // Are you sure about uninstall this module?
$_MODULE['<{paygine}prestashop>paygine_978b14d8e497f3ebc867466d3ead5af6'] = 'Перед использованием настройте модуль.'; // Paygine account details must be configured before using this module.
$_MODULE['<{paygine}prestashop>paygine_a02758d758e8bec77a33d7f392eb3f8a'] = 'Вылюта не была выбрана для этого модуля'; // No currency has been set for this module.
$_MODULE['<{paygine}prestashop>paygine_078c8a4d78a3b95068066b07782ec1c2'] = 'Ожидается оплата картой'; // Awaiting payment by card

$_MODULE['<{paygine}prestashop>paygine_14959fa24a78e322c86677c124f3e9dc'] = 'Принимайте платежи по банковским картам'; // This module allows you to accept payments by credit and debit cards
$_MODULE['<{paygine}prestashop>paygine_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки сохранены'; // Settings updated
$_MODULE['<{paygine}prestashop>paygine_95c99cc6506cbbf43fe1209282517db7'] = 'Оплата банковской картой'; // Pay by credit or debit card
$_MODULE['<{paygine}prestashop>paygine_e0344b13f3d320411ac648f495268e23'] = 'Информация об учётной записи Paygine';
$_MODULE['<{paygine}prestashop>paygine_39d8e78110e209ab92d72a61ab75f7f3'] = 'Sector ID'; // Sector ID
$_MODULE['<{paygine}prestashop>paygine_121c63480065077a06acf73ccceab6bf'] = 'Ваш индивидуальный номер клиента'; // Your individual customer number
$_MODULE['<{paygine}prestashop>paygine_90657ed44f48773e19de9c75835beed5'] = 'Поле Sector ID должно быть заполнено'; // Sector ID field is required.
$_MODULE['<{paygine}prestashop>paygine_dc647eb65e6711e155375218212b3964'] = 'Пароль'; // Password
$_MODULE['<{paygine}prestashop>paygine_93d74a07f6022a01d61a5a2da7fd8370'] = 'Пароль, используемый для формирования цифровой подписи'; // Password used to generate a digital signature
$_MODULE['<{paygine}prestashop>paygine_375df1fda0b20b05a7bee769524a3181'] = 'Поле Пароль должно быть заполнено'; // Password field is required.
$_MODULE['<{paygine}prestashop>paygine_4245499695408b974322be6f01b0d17a'] = 'Тестовый режим'; // Test mode
$_MODULE['<{paygine}prestashop>paygine_c080ce216207ba861150dec8134fd388'] = 'Использовать эмуляцию реальной работы. Средства с покупателя списаны не будут'; // Use emulation of real work. Buyer will not be charged
$_MODULE['<{paygine}prestashop>paygine_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить'; // Save
$_MODULE['<{paygine}prestashop>paygine_f0aaaae189e9c7711931a65ffcd22543'] = 'Способ оплаты'; // Payment method
$_MODULE['<{paygine}prestashop>paygine_93b276c00252a68c35fe0d34cea4a699'] = 'Стандартный эквайринг (одностадийная оплата)'; // Standard acquiring (one-stage payment)
$_MODULE['<{paygine}prestashop>paygine_00f0af126889cbd1ec563c1956cac570'] = 'Стандартный эквайринг (двухстадийная оплата)'; // Standard acquiring (two-stage payment)
$_MODULE['<{paygine}prestashop>paygine_0798c9d0bf9806e0c5544a4213027178'] = 'Только Халва Частями (одностадийная оплата)'; // Halva Chastyami (one-stage payment)
$_MODULE['<{paygine}prestashop>paygine_1b824e87d350680ec707407b74886778'] = 'Только Халва Частями (двухстадийная оплата)'; // Halva Chastyami (two-stage payment)
$_MODULE['<{paygine}prestashop>paygine_fb39709cad9928a75aa973a4900bbe3e'] = 'Система Быстрых Платежей'; // Fast Payment System
$_MODULE['<{paygine}prestashop>paygine_23b6620842f233aef2bdcfd7d54ff256'] = 'Оплата происходит после подтверждения менеджером в ЛК'; // Payment occurs after confirmation by the manager in the personal account
$_MODULE['<{paygine}prestashop>paygine_32f2ae7f63ddfd7622fdd78920197df8'] = 'Открывать пейформу в модальном окне'; // Open the payment form in modal window
$_MODULE['<{paygine}prestashop>paygine_521c36a31c2762741cf0f8890cbe05e3'] = 'Вкл.'; // On
$_MODULE['<{paygine}prestashop>paygine_d15305d7a4e34e02489c74a5ef542f36'] = 'Выкл.'; // Off
$_MODULE['<{paygine}prestashop>paygine_8a9404efa214f4139fda561773363aa5'] = 'При включенной опции форма оплаты открывается в модальном окне.'; // When this option is enabled, the payment form opens in a modal window.
$_MODULE['<{paygine}prestashop>paygine_4b78ac8eb158840e9638a3aeb26c4a9d'] = 'Налог';
$_MODULE['<{paygine}prestashop>paygine_a40d4f6bc5af8cc075c7862256431b88'] = 'ставка НДС 20%';
$_MODULE['<{paygine}prestashop>paygine_d2fa23f2eed8464b25ca3427d257dae3'] = 'ставка НДС 10%';
$_MODULE['<{paygine}prestashop>paygine_6fb1a535a1806e14e9717437fbe06ea8'] = 'ставка НДС расч. 20/120';
$_MODULE['<{paygine}prestashop>paygine_a36fb04519eb9838868f8ca8ff1bccb2'] = 'ставка НДС расч. 10/110';
$_MODULE['<{paygine}prestashop>paygine_3c80df4c4980ad99e3d8513abb64b159'] = 'ставка НДС 0%';
$_MODULE['<{paygine}prestashop>paygine_25a20fe40d1793cec210b4b8e8cd846a'] = 'НДС не облагается';
$_MODULE['<{paygine}prestashop>paygine_d057bc4905cb95a74b4f9340db6927e9'] = 'Настраиваемые статусы для заказов'; // Custom statuses for orders
$_MODULE['<{paygine}prestashop>paygine_415d0eb7b1b3c6994e364a5e6c5ec5ad'] = 'Платеж выполнен'; // Payment completed
$_MODULE['<{paygine}prestashop>paygine_7e7faa3b1b620dd21b3886f46d36f1e6'] = 'Средства захолдированы'; // Payment authorized
$_MODULE['<{paygine}prestashop>paygine_38a4d6de8ac44592dfe6e0138b8d28c1'] = 'Платеж возвращен'; // Payment refunded
$_MODULE['<{paygine}prestashop>paygine_78ffc7529abfa8dcfcb8607c06ecec00'] = 'URL для уведомлений'; // Notify URL
$_MODULE['<{paygine}prestashop>paygine_d64223717790468e3469f3ff69a7a5ff'] = 'Сообщите в службу технической поддержки Paygine этот URL для получения уведомлений о платеже'; // Report this URL to Paygine technical support to receive payment notifications

$_MODULE['<{paygine}prestashop>paygine_ae94f80b3ce82062a5dd7815daa04f9d'] = 'Списать средства'; // Complete
$_MODULE['<{paygine}prestashop>paygine_76f0ed934de85cc7131910b32ede7714'] = 'Отменить платеж'; // Refund
$_MODULE['<{paygine}prestashop>paygine_e8e96372eca3593f1361bde199e32e85'] = 'Paygine не поддерживает частичный возврат средств'; // Paygine does not support partial refund
$_MODULE['<{paygine}prestashop>paygine_e0bb742c0332aa424715446da348be41'] = 'Средства за заказ успешно списаны!'; // Payment complete successful!
$_MODULE['<{paygine}prestashop>paygine_dc9471cc49d0d4e19a559ae1f719e00e'] = 'Возврат средств выполнен успешно!'; // Payment refunded successful!

$_MODULE['<{paygine}prestashop>paygine_ad92169e95e13b3fcd8bad5afedbd49b'] = 'Ошибка валидации'; // Validation error
$_MODULE['<{paygine}prestashop>paygine_f1e9349dc8cdbb4a1dede7adc543e5fd'] = 'Ошибка валюты'; // Currency error
$_MODULE['<{paygine}prestashop>paygine_0c10653c4d0cd7ad7f145075e5f9e06f'] = 'Ошибка адреса'; // Address error
$_MODULE['<{paygine}prestashop>paygine_8dde2d34a22c375465c0004a4d0401f3'] = 'Не удалось создать заказ. Пожалуйста, попробуйте позже.'; // Failed to create order. Please try later.
$_MODULE['<{paygine}prestashop>paygine_134f563617c17cc97634517e74a82f0f'] = 'Ошибка создания контекста потока'; // Creates a stream context failed
$_MODULE['<{paygine}prestashop>paygine_f344657343f1465c0e5f9503a37ad69e'] = 'Пустой ответ сервера'; // Empty response
$_MODULE['<{paygine}prestashop>paygine_b80d130bd078d577d37f3fdb632655dc'] = 'Неверный XML'; // Invalid XML
$_MODULE['<{paygine}prestashop>paygine_d9f729716ff34480d1098642d7b1dae7'] = 'Пустая подпись'; // Empty signature
$_MODULE['<{paygine}prestashop>paygine_fca3fbced675f75182786525bf4706dc'] = 'Неверная подпись'; // Invalid signature
$_MODULE['<{paygine}prestashop>paygine_087f22572dc6f66ebe977c1c8d89fdd4'] = 'Неизвестный тип операции'; // Unknown operation type
$_MODULE['<{paygine}prestashop>paygine_24909e87dc242b9dd539e10609b8b050'] = 'Заказ не найден'; // Order not found
$_MODULE['<{paygine}prestashop>paygine_bc7f18325750e90606655c4c5796c7e6'] = 'Операция не одобрена'; // Operation not approved
$_MODULE['<{paygine}prestashop>paygine_db4b09d336794d3e5a1ffa30a22153c5'] = 'Отсутствует идентификатор заказа'; // Order ID is empty
$_MODULE['<{paygine}prestashop>paygine_f0d0e1232e2c8e7b7e055a649265aab3'] = 'Не удалось списать средства. Попробуйте позже'; // Failed to complete Order. Try again later
$_MODULE['<{paygine}prestashop>paygine_9985c93e9de5d25c67dfa346bcca5fba'] = 'Не удалось вернуть средства. Попробуйте позже'; // Failed to refund Order. Try again later
$_MODULE['<{paygine}prestashop>paygine_979c6094728c14aac1b66d544dc5cebd'] = 'Недопустимый статус заказа'; // Invalid order state
$_MODULE['<{paygine}prestashop>paygine_015b95433b8f5634bebd00f6e5357bbe'] = 'В запросе отсутствует идентификатор заказа Paygine'; // Missing Paygine Order ID in the request
$_MODULE['<{paygine}prestashop>paygine_528ce3ad2c33175b39806b5df2272f95'] = 'Отсутствует идентификатор заказа в запросе'; // Missing Order ID in the request
$_MODULE['<{paygine}prestashop>paygine_36d7a94c992b363a4f730ac56ff268df'] = 'Отсутствует идентификатор операции в запросе'; // Missing Operation ID in the request

$_MODULE['<{paygine}prestashop>paygine_3b6b1fefd7c22aef138d34e01d4fa76e'] = 'Заказ успешно оплачен'; // Order successfully paid
$_MODULE['<{paygine}prestashop>paygine_495f6462494d976a062e278843a5834f'] = 'Произошла ошибка при оплате заказа'; // An error occurred while paying for the order
$_MODULE['<{paygine}prestashop>paygine_065ab3a28ca4f16f55f103adc7d0226f'] = 'Доставка'; // Delivery
$_MODULE['<{paygine}prestashop>paygine_104d9898c04874d0fbac36e125fa1369'] = 'Скидка'; // Discount
$_MODULE['<{paygine}prestashop>paygine_42a4da30e8688c72e08f7d6c8126380a'] = 'Заказ #%s';
$_MODULE['<{paygine}prestashop>paygine_1620eb54af4ed7523bab6a17fdea9177'] = 'Ваши настройки округления не полностью совместимы с требованиями Paygine.<br/>Чтобы избежать сбоя некоторых транзакций, измените'; // Your rounding settings are not fully compatible with Paygine requirements.<br/>In order to avoid some of the transactions to fail, please change
$_MODULE['<{paygine}prestashop>paygine_2f75d29d254a7065c788fa995d11304a'] = ' режим округления PrestaShop в <a href="@href1@" target="blank">Параметры магазина > Общие</a>'; //  the PrestaShop rounding mode in <a href="@href1@" target="blank"> Preferences > General</a> to
$_MODULE['<{paygine}prestashop>roundingwarning_311947b46c34161a5484812ec0090707'] = 'Режим округления: "Округление половины в сторону от ноля  (рекомендовано)"';//'Round mode: "Round up away from zero, when it is half way there (recommended)"';
$_MODULE['<{paygine}prestashop>roundingwarning_27a3066cd34cd1e683f1c2d04483163a'] = 'Тип округления: "Округление каждого элемента"';//'Round type: "Round on each item"';

$_MODULE['<{paygine}prestashop>payment_execution_644818852b4dd8cf9da73543e30f045a'] = 'Вернуться к оформлению заказа';
$_MODULE['<{paygine}prestashop>payment_execution_6ff063fbc860a79759a7369ac32cee22'] = 'Оформление заказа';
$_MODULE['<{paygine}prestashop>payment_execution_1bf413f0447663cac0aba8526bef40dc'] = 'Оплата банковской картой';
$_MODULE['<{paygine}prestashop>payment_execution_879f6b8877752685a966564d072f498f'] = 'Ваша корзина пуста.';
$_MODULE['<{paygine}prestashop>payment_execution_a69d841c55154fc8b344e19ea27ab4e0'] = 'Оплата банковской картой';
$_MODULE['<{paygine}prestashop>payment_execution_01370908c97caac243b246ef2661d3a5'] = 'Мы принимаем банковские карты МИР, Visa, MasterCard';
$_MODULE['<{paygine}prestashop>payment_execution_e797937af3dec0b41c330d933659ff81'] = 'Нажмите \'Оплатить\' для перехода на платёжную страницу.';
$_MODULE['<{paygine}prestashop>payment_execution_3cfd82f426314baac679a85da388c8b7'] = 'Оплатить';

$_MODULE['<{paygine}prestashop>payment_return_88526efe38fd18179a127024aba8c1d7'] = 'Ваш заказ в %s завершён.';
$_MODULE['<{paygine}prestashop>payment_return_d15feee53d81ea16269e54d4784fa123'] = 'Мы обнаружили проблему в вашем заказе. Свяжитесь с';
$_MODULE['<{paygine}prestashop>payment_return_66fcf4c223bbf4c7c886d4784e1f62e4'] = 'нашей командой техподдержки';
$_MODULE['<{paygine}prestashop>payment_b6fd4b0910197b56e37e688b1184ff65'] = 'Оплата банковской картой';
$_MODULE['<{paygine}prestashop>payment_750a646892645279f465bbdf80e897b5'] = '(онлайн)';
